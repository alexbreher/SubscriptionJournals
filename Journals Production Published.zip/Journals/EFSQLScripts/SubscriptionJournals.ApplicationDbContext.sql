﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210904020503_Init')
BEGIN
    CREATE TABLE [Users] (
        [user_Id] int NOT NULL IDENTITY,
        [user] nvarchar(50) NOT NULL,
        [name] nvarchar(50) NOT NULL,
        [Password] nvarchar(100) NOT NULL,
        [lastName] nvarchar(80) NOT NULL,
        [email] nvarchar(80) NOT NULL,
        [token] nvarchar(80) NULL,
        [creationDate] datetime2 NOT NULL,
        [followers] int NOT NULL,
        [following] int NOT NULL,
        [journalsPublished] int NOT NULL,
        CONSTRAINT [PK_Users] PRIMARY KEY ([user_Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210904020503_Init')
BEGIN
    CREATE TABLE [Journals] (
        [journal_Id] int NOT NULL IDENTITY,
        [name] nvarchar(100) NOT NULL,
        [author] int NOT NULL,
        [creationDate] datetime2 NOT NULL,
        [path] nvarchar(max) NULL,
        CONSTRAINT [PK_Journals] PRIMARY KEY ([journal_Id]),
        CONSTRAINT [FK_Journals_Users_author] FOREIGN KEY ([author]) REFERENCES [Users] ([user_Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210904020503_Init')
BEGIN
    CREATE TABLE [Subscriptions] (
        [subscription_Id] int NOT NULL IDENTITY,
        [subscriptor] int NOT NULL,
        [subscribesTo] int NOT NULL,
        [subscriptionDate] datetime2 NOT NULL,
        CONSTRAINT [PK_Subscriptions] PRIMARY KEY ([subscription_Id]),
        CONSTRAINT [FK_Subscriptions_Users_subscribesTo] FOREIGN KEY ([subscribesTo]) REFERENCES [Users] ([user_Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210904020503_Init')
BEGIN
    CREATE INDEX [IX_Journals_author] ON [Journals] ([author]);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210904020503_Init')
BEGIN
    CREATE INDEX [IX_Subscriptions_subscribesTo] ON [Subscriptions] ([subscribesTo]);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210904020503_Init')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20210904020503_Init', N'5.0.9');
END;
GO

COMMIT;
GO

