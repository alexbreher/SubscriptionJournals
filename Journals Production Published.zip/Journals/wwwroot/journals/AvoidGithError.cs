﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SubscriptionJournals.wwwroot.journals
{
    public class AvoidGithError
    {
    }
}
